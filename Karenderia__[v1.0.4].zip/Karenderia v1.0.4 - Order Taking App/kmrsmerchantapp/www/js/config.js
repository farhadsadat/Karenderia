
var krms_config ={			
	'ApiUrl' : "YOUR_API_URL",	
	'DialogDefaultTitle' : "YOUR_OWN_DIALOG_TITLE",
	'pushNotificationSenderid' : "YOUR_ANDROID_PUSH_PROJECT_ID",
	'APIHasKey' : "YOUR API HASH KEY (OPTIONAL)"
};